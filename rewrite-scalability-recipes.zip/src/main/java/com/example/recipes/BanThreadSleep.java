package com.example.recipes;

import org.openrewrite.ExecutionContext;
import org.openrewrite.Recipe;
import org.openrewrite.java.JavaIsoVisitor;
import org.openrewrite.java.tree.J;
import org.openrewrite.java.template.JavaTemplate;
import org.openrewrite.java.tree.TypeUtils;
import org.openrewrite.TreeVisitor;

public class BanThreadSleep extends Recipe {

    @Override
    public String getDisplayName() {
        return "Avoid Thread.sleep for scalability";
    }

    @Override
    public String getDescription() {
        return "Thread.sleep blocks threads and should be avoided in scalable applications.";
    }

    @Override
    protected TreeVisitor<?, ExecutionContext> getVisitor() {
        return new JavaIsoVisitor<ExecutionContext>() {
            @Override
            public J.MethodInvocation visitMethodInvocation(J.MethodInvocation method, ExecutionContext ctx) {
                method = super.visitMethodInvocation(method, ctx);
                if (method.getSimpleName().equals("sleep") &&
                    method.getSelect() != null &&
                    TypeUtils.isOfClassType(method.getSelect().getType(), "java.lang.Thread")) {
                    return method.withTemplate(
                            JavaTemplate.builder(() -> getCursor(), "// Avoid Thread.sleep for scalability").build(),
                            method.getCoordinates().replace()
                    );
                }
                return method;
            }
        };
    }
}
