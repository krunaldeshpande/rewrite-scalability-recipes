package com.example.recipes;

import org.openrewrite.ExecutionContext;
import org.openrewrite.Recipe;
import org.openrewrite.java.JavaIsoVisitor;
import org.openrewrite.java.template.JavaTemplate;
import org.openrewrite.java.tree.J;
import org.openrewrite.java.tree.TypeUtils;
import org.openrewrite.TreeVisitor;

public class BanFixedThreadPool extends Recipe {

    @Override
    public String getDisplayName() {
        return "Avoid Executors.newFixedThreadPool";
    }

    @Override
    public String getDescription() {
        return "newFixedThreadPool can lead to thread exhaustion and is not scalable.";
    }

    @Override
    protected TreeVisitor<?, ExecutionContext> getVisitor() {
        return new JavaIsoVisitor<ExecutionContext>() {
            @Override
            public J.MethodInvocation visitMethodInvocation(J.MethodInvocation method, ExecutionContext ctx) {
                method = super.visitMethodInvocation(method, ctx);
                if (method.getSimpleName().equals("newFixedThreadPool") &&
                    method.getSelect() != null &&
                    TypeUtils.isOfClassType(method.getSelect().getType(), "java.util.concurrent.Executors")) {
                    return method.withTemplate(
                        JavaTemplate.builder(() -> getCursor(), "// Avoid Executors.newFixedThreadPool - consider virtual threads or cached thread pool").build(),
                        method.getCoordinates().replace()
                    );
                }
                return method;
            }
        };
    }
}
