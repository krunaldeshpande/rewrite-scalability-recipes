package com.example.recipes;

import org.openrewrite.ExecutionContext;
import org.openrewrite.Recipe;
import org.openrewrite.java.JavaIsoVisitor;
import org.openrewrite.java.template.JavaTemplate;
import org.openrewrite.java.tree.J;
import org.openrewrite.java.tree.TypeUtils;
import org.openrewrite.TreeVisitor;

public class ReplaceHashMapWithConcurrentHashMap extends Recipe {

    @Override
    public String getDisplayName() {
        return "Use ConcurrentHashMap instead of HashMap in multi-threaded context";
    }

    @Override
    public String getDescription() {
        return "HashMap is not thread-safe. Use ConcurrentHashMap for scalable access.";
    }

    @Override
    protected TreeVisitor<?, ExecutionContext> getVisitor() {
        return new JavaIsoVisitor<ExecutionContext>() {
            @Override
            public J.NewClass visitNewClass(J.NewClass newClass, ExecutionContext ctx) {
                if (TypeUtils.isOfClassType(newClass.getType(), "java.util.HashMap")) {
                    return newClass.withTemplate(
                        JavaTemplate.builder(() -> getCursor(), "new java.util.concurrent.ConcurrentHashMap<>()").build(),
                        newClass.getCoordinates().replace()
                    );
                }
                return super.visitNewClass(newClass, ctx);
            }
        };
    }
}
